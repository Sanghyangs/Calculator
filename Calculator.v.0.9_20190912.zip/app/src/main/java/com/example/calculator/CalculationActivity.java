package com.example.calculator;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.text.InputType;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import java.util.Arrays;

public class CalculationActivity extends AppCompatActivity {
    private int MAX_MEMBER = 3;
    private final int MAX_OPTIONS = 5;
    private final int NUM_PRICE_INFO = 4;
    private final int NUM_OPTIONS = 3;
    
    int[][] personalPriceArray = new int[MAX_MEMBER][NUM_PRICE_INFO]; //[누구인지 구분][1차,2차,3차, 총 비용]
    int[][] optionArray = new int[MAX_OPTIONS][NUM_OPTIONS]; //[옵션][1차, 2차, 3차]
    int[] peopleArray = new int[NUM_OPTIONS]; //[1차, 2차, 3차 인원]
    int[] totalPriceArray = new int[NUM_OPTIONS]; //[1차, 2차, 3차 비용]
    int[] snackArray = new int[NUM_OPTIONS]; //[1차, 2차, 3차 안주개수]
    int[] totalCount = new int[NUM_OPTIONS]; //인원수

    int[][] editTextArray = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculation);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        SharedPreferences myPref = PreferenceManager.getDefaultSharedPreferences(getApplicationContext());
        String strValue = myPref.getString("numAttendee", String.valueOf(MAX_MEMBER));
        MAX_MEMBER = Integer.valueOf(strValue);

        cleanupEditTextTable();

        editTextArray = new int[MAX_MEMBER][MAX_OPTIONS];
        setupEditTextTable(MAX_MEMBER);

        Button btnOut = (Button) findViewById(R.id.btnOut);
        btnOut.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strClipText = "이름  1차  2차  3차  총 비용" + System.getProperty("line.separator");

                for (int index = 0; index < MAX_MEMBER; index++) {
                    EditText etEntry = (EditText) findViewById(editTextArray[index][0]);
                    String strName = etEntry.getText().toString();

                    String strEntry = String.format("%4s %4d %4d %4d %4d", strName,
                            personalPriceArray[index][0], personalPriceArray[index][1], personalPriceArray[index][2], personalPriceArray[index][3]);

                    strClipText += strEntry + System.getProperty("line.separator");
                }

                ClipboardManager clipboard = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("text", strClipText);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(getApplicationContext(), "클립보드에 복사되었습니다.", Toast.LENGTH_LONG).show();
            }
        });

        Button btnCalculate = (Button) findViewById(R.id.btnCalculate);
        btnCalculate.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculatePrice();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case R.id.action_settings:
                Intent intentSettings = new Intent(getApplicationContext(), SettingsActivity.class);
                startActivity(intentSettings);
                return true;    //break;

            case R.id.action_about:
                Intent intent_info = new Intent(getApplicationContext(), InformationActivity.class);
                startActivity(intent_info);
                return true;    //break;

            case R.id.action_help:
                Intent intent_help = new Intent(getApplicationContext(), HelpActivity.class);
                startActivity(intent_help);
                return true;    //break;

            case R.id.action_quit:
                finish();
                return true;    //break;
        }

        return super.onOptionsItemSelected(item);
    }

    private int setOptionArray() {
        for (int[] row : optionArray)
            Arrays.fill(row, 0);
        //    int[][] optionArray = new int[MAX_OPTIONS][NUM_OPTIONS]; //[옵션][1차, 2차, 3차]
        int numAttendee = editTextArray.length;
        String strInfo = null;

        for (int iLoop = 0; iLoop < numAttendee; iLoop++) {
            int optionNumber = 0;
            EditText etEntry = (EditText) findViewById(editTextArray[iLoop][1]);
            String strText = etEntry.getText().toString();
            if (strText.length() == 0) {
                optionNumber = 0;
            } else {
                optionNumber = Integer.valueOf(strText);
            }

            if ((optionNumber > 0) && (optionNumber < 6)) {
                optionArray[optionNumber - 1][0]++;
            } else {
                etEntry.setText("");
                etEntry.requestFocus();
                Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
                return -1;
            }

            etEntry = (EditText) findViewById(editTextArray[iLoop][2]);
            strText = etEntry.getText().toString();
            if (strText.length() == 0) {
                optionNumber = 0;
            } else {
                optionNumber = Integer.valueOf(strText);
            }

            if ((optionNumber > 0) && (optionNumber < 6)) {
                optionArray[optionNumber - 1][1]++;
            } else {
                etEntry.setText("");
                etEntry.requestFocus();
                Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
                return -1;
            }

            etEntry = (EditText) findViewById(editTextArray[iLoop][3]);
            strText = etEntry.getText().toString();
            if (strText.length() == 0) {
                optionNumber = 0;
            } else {
                optionNumber = Integer.valueOf(strText);
            }

            if ((optionNumber > 0) && (optionNumber < 6)) {
                optionArray[optionNumber - 1][2]++;
            } else {
                etEntry.setText("");
                etEntry.requestFocus();
                Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
                return -1;
            }
        }
        return 0;
    }

    private void setPeopleArray() {
        int index = 0;
        peopleArray[0] = optionArray[0][index] + optionArray[1][index] + optionArray[2][index] + optionArray[3][index];
        index++;

        peopleArray[1] = optionArray[0][index] + optionArray[1][index] + optionArray[2][index] + optionArray[3][index];
        index++;

        peopleArray[2] = optionArray[0][index] + optionArray[1][index] + optionArray[2][index] + optionArray[3][index];
    }

    private int setTotalPriceArray() {
        Arrays.fill(totalPriceArray, 0);
        //int[] totalPriceArray = new int[NUM_OPTIONS]; //[1차, 2차, 3차 비용]
        int index = 0;
        EditText etEntry = (EditText) findViewById(R.id.editText_sum_1);
        String strText = etEntry.getText().toString();
        if (strText.length() == 0) {
            etEntry.setText("");
            etEntry.requestFocus();
            Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
            return -1;
        }
        totalPriceArray[index++] = Integer.valueOf(strText);

        etEntry = (EditText) findViewById(R.id.editText_sum_2);
        strText = etEntry.getText().toString();
        if (strText.length() == 0) {
            etEntry.setText("");
            etEntry.requestFocus();
            Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
            return -1;
        }
        totalPriceArray[index++] = Integer.valueOf(strText);

        etEntry = (EditText) findViewById(R.id.editText_sum_3);
        strText = etEntry.getText().toString();
        if (strText.length() == 0) {
            etEntry.setText("");
            etEntry.requestFocus();
            Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
            return -1;
        }
        totalPriceArray[index++] = Integer.valueOf(strText);

        return 0;
    }

    private int setSnackArray() {
        Arrays.fill(snackArray, 0);
        //int[] snackArray = new int[NUM_OPTIONS]; //[1차, 2차, 3차 안주개수]
        int index = 0;
        EditText etEntry = (EditText) findViewById(R.id.editText_snack_1);
        String strText = etEntry.getText().toString();
        if (strText.length() == 0) {
            etEntry.setText("");
            etEntry.requestFocus();
            Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
            return -1;
        }
        snackArray[index++] = Integer.valueOf(strText);

        etEntry = (EditText) findViewById(R.id.editText_snack_2);
        strText = etEntry.getText().toString();
        if (strText.length() == 0) {
            etEntry.setText("");
            etEntry.requestFocus();
            Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
            return -1;
        }
        snackArray[index++] = Integer.valueOf(strText);

        etEntry = (EditText) findViewById(R.id.editText_snack_3);
        strText = etEntry.getText().toString();
        if (strText.length() == 0) {
            etEntry.setText("");
            etEntry.requestFocus();
            Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
            return -1;
        }
        snackArray[index++] = Integer.valueOf(strText);

        return 0;
    }

    private void calculatePrice() {
        int row = editTextArray.length;
        int column = editTextArray[0].length;
        String strInfo = null;

        if (setOptionArray() != 0) {
            return;
        }

        setPeopleArray();

        if (setTotalPriceArray() != 0) {
            return;
        }

        if (setSnackArray() != 0) {
            return;
        }

        int snackprice = 0;
        int newprice = 0;

        for (int j = 0; j < 3; j++) {
            if (peopleArray[j] == 0) {
                continue;
            }

            switch (snackArray[j]) {
                case 1:
                    snackprice = 5000;
                    break;
                default:
                    snackprice = snackArray[j] * 4000;
                    break;
            }

            newprice = (totalPriceArray[j] + (snackprice * optionArray[1][j]) + (4000 * optionArray[2][j]) + (snackprice + 4000) * optionArray[3][j]);

            for (int i = 0; i < MAX_MEMBER; i++) {
                EditText etEntry = (EditText) findViewById(editTextArray[i][j + 1]);
                String strText2 = etEntry.getText().toString();
                int option = Integer.valueOf(strText2);

                switch (option) {
                    case 1:
                        if (((newprice) / (peopleArray[j])) <= 1000) {
                            personalPriceArray[i][j] = 1000;
                        }
                        else
                            personalPriceArray[i][j] = ((newprice) / (peopleArray[j]));
                        break;
                    case 2:
                        if ((((newprice) / (peopleArray[j])) - (snackprice)) <= 1000) {
                            personalPriceArray[i][j] = 1000;
                        }
                        else
                            personalPriceArray[i][j] = (((newprice) / (peopleArray[j])) - (snackprice));
                        break;
                    case 3:
                        if ((((newprice) / (peopleArray[j])) - (4000)) <= 1000) {
                            personalPriceArray[i][j] = 1000;
                        }
                        else
                            personalPriceArray[i][j] = (((newprice) / (peopleArray[j])) - (4000));
                        break;
                    case 4:
                        if ((((newprice) / (peopleArray[j])) - ((snackprice) + (4000))) <= 1000) {
                            personalPriceArray[i][j] = 1000;
                        }
                        else
                            personalPriceArray[i][j] = ((newprice) / (peopleArray[j])) - ((snackprice) + (4000));
                        break;
                    default:
                        break;
                }
            }
        }
        for (int fin = 0; fin < MAX_MEMBER; fin++){
            personalPriceArray[fin][3] = ((((personalPriceArray[fin][0] + personalPriceArray[fin][1] + personalPriceArray[fin][2]) / (500)) + 1) * (500));
        }

        for (int iLoop = 0; iLoop < row; iLoop++) {
            EditText etEntry = (EditText) findViewById(editTextArray[iLoop][4]);
            String strPrice = String.valueOf(personalPriceArray[iLoop][3]);

            etEntry.setText(strPrice);
        }
    }

    private void setupEditTextTable(int numRow) {
        TableLayout tableLayout =(TableLayout)findViewById(R.id.memberTable);
        for (int rowIndex = 0; rowIndex < numRow; rowIndex++) {
            int id, columnIndex = 0;
            int arrayRowId[] = new int[5];
            TableRow row = new TableRow(this);
            row.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT));
            row.setGravity(Gravity.CENTER);
            row.setWeightSum(10); //total row weight
            tableLayout.addView(row);

            EditText et = new EditText(this);
            id = View.generateViewId();
            et.setId(id);
            arrayRowId[columnIndex++] = id;
            TableRow.LayoutParams lp = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 2f);
            et.setLayoutParams(lp);
            row.addView(et);

            et = new EditText(this);
            et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
            id = View.generateViewId();
            et.setId(id);
            arrayRowId[columnIndex++] = id;
            lp = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 2f);
            et.setLayoutParams(lp);
            row.addView(et);

            et = new EditText(this);
            et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
            id = View.generateViewId();
            et.setId(id);
            arrayRowId[columnIndex++] = id;
            lp = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 2f);
            et.setLayoutParams(lp);
            row.addView(et);

            et = new EditText(this);
            et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
            id = View.generateViewId();
            et.setId(id);
            arrayRowId[columnIndex++] = id;
            lp = new TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 2f);
            et.setLayoutParams(lp);
            row.addView(et);

            et = new EditText(this);
            et.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
            id = View.generateViewId();
            et.setId(id);
            arrayRowId[columnIndex++] = id;
            et.setLayoutParams(lp);
            et.setEnabled(false);
            row.addView(et);

            editTextArray[rowIndex] = arrayRowId;
        }
    }

    private void cleanupEditTextTable() {
        TableLayout tableLayout = (TableLayout) findViewById(R.id.memberTable);

        tableLayout.removeAllViews();
    }

}

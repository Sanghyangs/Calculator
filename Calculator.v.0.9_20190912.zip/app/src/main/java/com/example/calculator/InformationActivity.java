package com.example.calculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class InformationActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        String strInformationText = "제작자: 이상민\n"
            + "고려대학교 컴퓨터학과 18학번\n"
            + "E-mail: rndtn115@korea.ac.kr\n"
            + "\n"
            + "문의사항 혹은 오류 발생시 연락 바랍니다.";
        TextView tvInformation = findViewById(R.id.textView_info);
        tvInformation.setText(strInformationText);

        Button btnBack = (Button) findViewById(R.id.button_back);
        btnBack.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case R.id.action_settings:
                Intent intentSettings = new Intent(getApplicationContext(), SettingsActivity.class);
                startActivity(intentSettings);
                return true;    //break;

            case R.id.action_about:
                Intent intent_info = new Intent(getApplicationContext(), InformationActivity.class);
                startActivity(intent_info);
                return true;    //break;

            case R.id.action_help:
                Intent intent_help = new Intent(getApplicationContext(), HelpActivity.class);
                startActivity(intent_help);
                return true;    //break;

            case R.id.action_quit:
                finish();
                return true;    //break;
        }

        return super.onOptionsItemSelected(item);
    }
}

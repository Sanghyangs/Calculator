package com.example.calculator;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class HelpActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        String strHelpText = "계산 탭에서 1차, 2차, 3차 아래의 칸에는 뒷풀이에서 무엇을 먹었는지에 따라 1, 2, 3, 4, 5로 기입하시면 됩니다.\n"
            + "(1: 술O, 안주O 2: 술O, 안주X 3: 술X, 안주O 4: 술X, 안주X 5: 불참)\n"
            + "계산 결과 총 뒷풀이 비용(1차+2차+3차) 보다\n"
            + "뒷풀이 정산 비용의 총합이 적게 나올 경우 기입 오류가 발생한 것입니다.\n"
            + "이 경우 다시 한번 기입 내용에 오류가 없는지 체크해 주십시오.\n"
            + "'총액'란에 나온 금액은 각 인원의 총 뒷풀이 비용입니다.\n"
            + "'내보내기' 버튼을 누르시면 계산 결과를 텍스트 파일로 저장할 수 있습니다.\n";
        TextView tvHelp = findViewById(R.id.textView_help);
        tvHelp.setText(strHelpText);

        Button btnBack = (Button) findViewById(R.id.button_back);
        btnBack.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        switch (id) {
            case R.id.action_settings:
                Intent intentSettings = new Intent(getApplicationContext(), SettingsActivity.class);
                startActivity(intentSettings);
                return true;    //break;

            case R.id.action_about:
                Intent intent_info = new Intent(getApplicationContext(), InformationActivity.class);
                startActivity(intent_info);
                return true;    //break;

            case R.id.action_help:
                Intent intent_help = new Intent(getApplicationContext(), HelpActivity.class);
                startActivity(intent_help);
                return true;    //break;

            case R.id.action_quit:
                finish();
                return true;    //break;
        }

        return super.onOptionsItemSelected(item);
    }
}

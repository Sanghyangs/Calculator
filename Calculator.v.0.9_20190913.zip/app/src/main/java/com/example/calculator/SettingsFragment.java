package com.example.calculator;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;


public class SettingsFragment extends PreferenceFragment {
    SharedPreferences myPref;
    EditTextPreference etpNumAttendee;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.settings_pref);

        myPref = PreferenceManager.getDefaultSharedPreferences(getContext().getApplicationContext());
        myPref.registerOnSharedPreferenceChangeListener(prefListener);

        etpNumAttendee = (EditTextPreference)findPreference("numAttendee");

        loadPrevConfig();
    }

    SharedPreferences.OnSharedPreferenceChangeListener prefListener = new SharedPreferences.OnSharedPreferenceChangeListener() {
        @Override
        public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
            String strValue = null;
            boolean bSave = false;

            switch (key) {
                case "numAttendee":
                    strValue = myPref.getString(key, "").trim();
                    bSave = true;
                    etpNumAttendee.setSummary(strValue);
                    break;

                default:
                    break;
            }

            if (bSave == true) {
                saveConfig();
            }
        }
    };

    @Override
    public void onStop() {
        super.onStop();

        saveConfig();
    }

    private void loadPrevConfig() {
        String strValue = myPref.getString("numAttendee", "").trim();
        if (strValue.isEmpty() == false) {
            etpNumAttendee.setSummary(strValue);
        }
    }

    private void saveConfig() {
        SharedPreferences.Editor editor = myPref.edit();

        editor.putString("numAttendee", (String) etpNumAttendee.getSummary());

        editor.commit();
    }

    private void enablePreference(boolean bEnable) {
        etpNumAttendee.setEnabled(bEnable);
    }
}
package com.example.calculator;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class Activity_calculation extends AppCompatActivity {
    private final int MAX_MEMBER = 2;
    private final int MAX_OPTIONS = 5;
    private final int NUM_PRICE_INFO = 4;
    private final int NUM_OPTIONS = 3;
    
    int[][] personalPriceArray = new int[MAX_MEMBER][NUM_PRICE_INFO]; //[누구인지 구분][1차,2차,3차, 총 비용]
    int[][] optionArray = new int[MAX_OPTIONS][NUM_OPTIONS]; //[옵션][1차, 2차, 3차]
    int[] peopleArray = new int[NUM_OPTIONS]; //[1차, 2차, 3차 인원]
    int[] totalPriceArray = new int[NUM_OPTIONS]; //[1차, 2차, 3차 비용]
    int[] snackArray = new int[NUM_OPTIONS]; //[1차, 2차, 3차 안주개수]
    int[] totalCount = new int[NUM_OPTIONS]; //인원수

    ArrayList<String> values = new ArrayList<String>();
    int[][] ids = new int[][] {
            { R.id.editText_Name1, R.id.editText_Name1_1, R.id.editTex_Name1_2, R.id.editText_Name1_3, R.id.editText_Name1_Sum },
            { R.id.editText_Name2, R.id.editText_Name2_1, R.id.editTex_Name2_2, R.id.editText_Name2_3, R.id.editText_Name2_Sum },
            /*
            { R.id.editText_Name3, R.id.editText_Name3_1, R.id.editTex_Name3_2, R.id.editText_Name3_3, R.id.editText_Name3_Sum },
            { R.id.editText_Name4, R.id.editText_Name4_1, R.id.editTex_Name4_2, R.id.editText_Name4_3, R.id.editText_Name4_Sum },
            { R.id.editText_Name5, R.id.editText_Name5_1, R.id.editTex_Name5_2, R.id.editText_Name5_3, R.id.editText_Name5_Sum },
            { R.id.editText_Name6, R.id.editText_Name6_1, R.id.editTex_Name6_2, R.id.editText_Name6_3, R.id.editText_Name6_Sum },
            { R.id.editText_Name7, R.id.editText_Name7_1, R.id.editTex_Name7_2, R.id.editText_Name7_3, R.id.editText_Name7_Sum },
            { R.id.editText_Name8, R.id.editText_Name8_1, R.id.editTex_Name8_2, R.id.editText_Name8_3, R.id.editText_Name8_Sum },
            { R.id.editText_Name9, R.id.editText_Name9_1, R.id.editTex_Name9_2, R.id.editText_Name9_3, R.id.editText_Name9_Sum },
            { R.id.editText_Name10, R.id.editText_Name10_1, R.id.editTex_Name10_2, R.id.editText_Name10_3, R.id.editText_Name10_Sum },
            { R.id.editText_Name11, R.id.editText_Name11_1, R.id.editTex_Name11_2, R.id.editText_Name11_3, R.id.editText_Name11_Sum },
            { R.id.editText_Name12, R.id.editText_Name12_1, R.id.editTex_Name12_2, R.id.editText_Name12_3, R.id.editText_Name12_Sum },
            { R.id.editText_Name13, R.id.editText_Name13_1, R.id.editTex_Name13_2, R.id.editText_Name13_3, R.id.editText_Name13_Sum },
            { R.id.editText_Name14, R.id.editText_Name14_1, R.id.editTex_Name14_2, R.id.editText_Name14_3, R.id.editText_Name14_Sum },
            { R.id.editText_Name15, R.id.editText_Name15_1, R.id.editTex_Name15_2, R.id.editText_Name15_3, R.id.editText_Name15_Sum },
            { R.id.editText_Name16, R.id.editText_Name16_1, R.id.editTex_Name16_2, R.id.editText_Name16_3, R.id.editText_Name16_Sum },
            { R.id.editText_Name17, R.id.editText_Name17_1, R.id.editTex_Name17_2, R.id.editText_Name17_3, R.id.editText_Name17_Sum },
            { R.id.editText_Name18, R.id.editText_Name18_1, R.id.editTex_Name18_2, R.id.editText_Name18_3, R.id.editText_Name18_Sum },
            { R.id.editText_Name19, R.id.editText_Name19_1, R.id.editTex_Name19_2, R.id.editText_Name19_3, R.id.editText_Name19_Sum },
            { R.id.editText_Name20, R.id.editText_Name20_1, R.id.editTex_Name20_2, R.id.editText_Name20_3, R.id.editText_Name20_Sum },
            { R.id.editText_Name21, R.id.editText_Name21_1, R.id.editTex_Name21_2, R.id.editText_Name21_3, R.id.editText_Name21_Sum },
            { R.id.editText_Name22, R.id.editText_Name22_1, R.id.editTex_Name22_2, R.id.editText_Name22_3, R.id.editText_Name22_Sum },
            { R.id.editText_Name23, R.id.editText_Name23_1, R.id.editTex_Name23_2, R.id.editText_Name23_3, R.id.editText_Name23_Sum },
            { R.id.editText_Name24, R.id.editText_Name24_1, R.id.editTex_Name24_2, R.id.editText_Name24_3, R.id.editText_Name24_Sum },
            { R.id.editText_Name25, R.id.editText_Name25_1, R.id.editTex_Name25_2, R.id.editText_Name25_3, R.id.editText_Name25_Sum },
            { R.id.editText_Name26, R.id.editText_Name26_1, R.id.editTex_Name26_2, R.id.editText_Name26_3, R.id.editText_Name26_Sum },
            { R.id.editText_Name27, R.id.editText_Name27_1, R.id.editTex_Name27_2, R.id.editText_Name27_3, R.id.editText_Name27_Sum },
            { R.id.editText_Name28, R.id.editText_Name28_1, R.id.editTex_Name28_2, R.id.editText_Name28_3, R.id.editText_Name28_Sum },
            { R.id.editText_Name29, R.id.editText_Name29_1, R.id.editTex_Name29_2, R.id.editText_Name29_3, R.id.editText_Name29_Sum },
            { R.id.editText_Name30, R.id.editText_Name30_1, R.id.editTex_Name30_2, R.id.editText_Name30_3, R.id.editText_Name30_Sum },
            { R.id.editText_Name31, R.id.editText_Name31_1, R.id.editTex_Name31_2, R.id.editText_Name31_3, R.id.editText_Name31_Sum },
            { R.id.editText_Name32, R.id.editText_Name32_1, R.id.editTex_Name32_2, R.id.editText_Name32_3, R.id.editText_Name32_Sum },
            { R.id.editText_Name33, R.id.editText_Name33_1, R.id.editTex_Name33_2, R.id.editText_Name33_3, R.id.editText_Name33_Sum },
            { R.id.editText_Name34, R.id.editText_Name34_1, R.id.editTex_Name34_2, R.id.editText_Name34_3, R.id.editText_Name34_Sum },
            { R.id.editText_Name35, R.id.editText_Name35_1, R.id.editTex_Name35_2, R.id.editText_Name35_3, R.id.editText_Name35_Sum },
            { R.id.editText_Name36, R.id.editText_Name36_1, R.id.editTex_Name36_2, R.id.editText_Name36_3, R.id.editText_Name36_Sum },
            { R.id.editText_Name37, R.id.editText_Name37_1, R.id.editTex_Name37_2, R.id.editText_Name37_3, R.id.editText_Name37_Sum },
            { R.id.editText_Name38, R.id.editText_Name38_1, R.id.editTex_Name38_2, R.id.editText_Name38_3, R.id.editText_Name38_Sum },
            { R.id.editText_Name39, R.id.editText_Name39_1, R.id.editTex_Name39_2, R.id.editText_Name39_3, R.id.editText_Name39_Sum },
            { R.id.editText_Name40, R.id.editText_Name40_1, R.id.editTex_Name40_2, R.id.editText_Name40_3, R.id.editText_Name40_Sum },
            { R.id.editText_Name41, R.id.editText_Name41_1, R.id.editTex_Name41_2, R.id.editText_Name41_3, R.id.editText_Name41_Sum },
            { R.id.editText_Name42, R.id.editText_Name42_1, R.id.editTex_Name42_2, R.id.editText_Name42_3, R.id.editText_Name42_Sum },
            { R.id.editText_Name43, R.id.editText_Name43_1, R.id.editTex_Name43_2, R.id.editText_Name43_3, R.id.editText_Name43_Sum },
            { R.id.editText_Name44, R.id.editText_Name44_1, R.id.editTex_Name44_2, R.id.editText_Name44_3, R.id.editText_Name44_Sum },
            { R.id.editText_Name45, R.id.editText_Name45_1, R.id.editTex_Name45_2, R.id.editText_Name45_3, R.id.editText_Name45_Sum },
            { R.id.editText_Name46, R.id.editText_Name46_1, R.id.editTex_Name46_2, R.id.editText_Name46_3, R.id.editText_Name46_Sum },
            { R.id.editText_Name47, R.id.editText_Name47_1, R.id.editTex_Name47_2, R.id.editText_Name47_3, R.id.editText_Name47_Sum },
            { R.id.editText_Name48, R.id.editText_Name48_1, R.id.editTex_Name48_2, R.id.editText_Name48_3, R.id.editText_Name48_Sum },
            { R.id.editText_Name49, R.id.editText_Name49_1, R.id.editTex_Name49_2, R.id.editText_Name49_3, R.id.editText_Name49_Sum },
            { R.id.editText_Name50, R.id.editText_Name50_1, R.id.editTex_Name50_2, R.id.editText_Name50_3, R.id.editText_Name50_Sum },
            */
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.content_activity_calculation);
        //Toolbar toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        Button btnOut = (Button) findViewById(R.id.btnOut);
        btnOut.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(), "TODO: 내보내기", Toast.LENGTH_LONG).show();

                String strClipText = "이름  1차  2차  3차  총 비용" + System.getProperty("line.separator");

                for (int index = 0; index < MAX_MEMBER; index++) {
                    EditText etEntry = (EditText) findViewById(ids[index][0]);
                    String strName = etEntry.getText().toString();

                    String strEntry = String.format("%4s %4d %4d %4d %4d", strName,
                            personalPriceArray[index][0], personalPriceArray[index][1], personalPriceArray[index][2], personalPriceArray[index][3]);

                    strClipText += strEntry + System.getProperty("line.separator");
                }

                ClipboardManager clipboard = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("text", strClipText);
                clipboard.setPrimaryClip(clip);
                Toast.makeText(getApplicationContext(), "클립보드에 복사되었습니다.", Toast.LENGTH_LONG).show();
            }
        });

        Button btnCalculate = (Button) findViewById(R.id.btnCalculate);
        btnCalculate.setOnClickListener(new Button.OnClickListener() {
            @Override
            public void onClick(View view) {
                calculatePrice();
            }
        });
    }

    private int setOptionArray() {
        //    int[][] optionArray = new int[MAX_OPTIONS][NUM_OPTIONS]; //[옵션][1차, 2차, 3차]
        int row = ids.length;
        //int column = ids[0].length;
        String strInfo = null;

        for (int iLoop = 0; iLoop < row; iLoop++) {
            int optionNumber = 0;
            EditText etEntry = (EditText) findViewById(ids[iLoop][1]);
            String strText = etEntry.getText().toString();
            if (strText.length() == 0) {
                optionNumber = 0;
            } else {
                optionNumber = Integer.valueOf(strText);
            }

            if ((optionNumber > 0) && (optionNumber < 6)) {
                optionArray[optionNumber - 1][0]++;
            } else {
                etEntry.setText("");
                //etEntry.setFocusable();
                Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
                return -1;
            }

            etEntry = (EditText) findViewById(ids[iLoop][2]);
            strText = etEntry.getText().toString();
            if (strText.length() == 0) {
                optionNumber = 0;
            } else {
                optionNumber = Integer.valueOf(strText);
            }

            if ((optionNumber > 0) && (optionNumber < 6)) {
                optionArray[optionNumber - 1][1]++;
            } else {
                etEntry.setText("");
                //etEntry.setFocusable();
                Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
                return -1;
            }

            etEntry = (EditText) findViewById(ids[iLoop][3]);
            strText = etEntry.getText().toString();
            if (strText.length() == 0) {
                optionNumber = 0;
            } else {
                optionNumber = Integer.valueOf(strText);
            }

            if ((optionNumber > 0) && (optionNumber < 6)) {
                optionArray[optionNumber - 1][2]++;
            } else {
                etEntry.setText("");
                //etEntry.setFocusable();
                Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
                return -1;
            }
        }
        return 0;
    }

    private void setPeopleArray() {
        int index = 0;
        peopleArray[0] = optionArray[1][index] + optionArray[2][index] + optionArray[3][index] + optionArray[4][index];
        index++;

        peopleArray[1] = optionArray[1][index] + optionArray[2][index] + optionArray[3][index] + optionArray[4][index];
        index++;

        peopleArray[2] = optionArray[1][index] + optionArray[2][index] + optionArray[3][index] + optionArray[4][index];

    }

    private int setTotalPriceArray() {
        //int[] totalPriceArray = new int[NUM_OPTIONS]; //[1차, 2차, 3차 비용]
        int index = 0;
        EditText etEntry = (EditText) findViewById(R.id.editText_sum_1);
        String strText = etEntry.getText().toString();
        if (strText.length() == 0) {
            etEntry.setText("");
            //etEntry.setFocusable();
            Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
            return -1;
        }
        totalPriceArray[index++] = Integer.valueOf(strText);

        etEntry = (EditText) findViewById(R.id.editText_sum_2);
        strText = etEntry.getText().toString();
        if (strText.length() == 0) {
            etEntry.setText("");
            //etEntry.setFocusable();
            Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
            return -1;
        }
        totalPriceArray[index++] = Integer.valueOf(strText);

        etEntry = (EditText) findViewById(R.id.editText_sum_3);
        strText = etEntry.getText().toString();
        if (strText.length() == 0) {
            etEntry.setText("");
            //etEntry.setFocusable();
            Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
            return -1;
        }
        totalPriceArray[index++] = Integer.valueOf(strText);

        return 0;
    }

    private int setSnackArray() {
        //int[] snackArray = new int[NUM_OPTIONS]; //[1차, 2차, 3차 안주개수]
        int index = 0;
        EditText etEntry = (EditText) findViewById(R.id.editText_snack_1);
        String strText = etEntry.getText().toString();
        if (strText.length() == 0) {
            etEntry.setText("");
            //etEntry.setFocusable();
            Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
            return -1;
        }
        snackArray[index++] = Integer.valueOf(strText);

        etEntry = (EditText) findViewById(R.id.editText_snack_2);
        strText = etEntry.getText().toString();
        if (strText.length() == 0) {
            etEntry.setText("");
            //etEntry.setFocusable();
            Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
            return -1;
        }
        snackArray[index++] = Integer.valueOf(strText);

        etEntry = (EditText) findViewById(R.id.editText_snack_3);
        strText = etEntry.getText().toString();
        if (strText.length() == 0) {
            etEntry.setText("");
            //etEntry.setFocusable();
            Toast.makeText(getApplicationContext(), "잘못된 입력입니다.", Toast.LENGTH_LONG).show();
            return -1;
        }
        snackArray[index++] = Integer.valueOf(strText);

        return 0;
    }

    private void calculatePrice() {
        int row = ids.length;
        int column = ids[0].length;
        String strInfo = null;

        // TODO: 모든 array를 초기화 하여야 함.
        if (setOptionArray() != 0) {
            Toast.makeText(getApplicationContext(), "오류가 발생했습니다.", Toast.LENGTH_LONG).show();
            return;
        }

        setPeopleArray();

        if (setTotalPriceArray() != 0) {
            Toast.makeText(getApplicationContext(), "오류가 발생했습니다.", Toast.LENGTH_LONG).show();
            return;
        }

        if (setSnackArray() != 0) {
            Toast.makeText(getApplicationContext(), "오류가 발생했습니다.", Toast.LENGTH_LONG).show();
            return;
        }

        int snackprice = 0;
        int newprice = 0;

        for (int j = 0; j < 3; j++) {
            switch (snackArray[j]) {
                case 1:
                    snackprice = 5000;
                    break;
                default:
                    snackprice = snackArray[j] * 4000;
                    break;
            }

            newprice = (totalPriceArray[j] + (snackprice * optionArray[1][j]) + (4000 * optionArray[2][j]) + (snackprice + 4000) * optionArray[3][j]);

            for (int i = 0; i < MAX_MEMBER; i++) {
                EditText etEntry = (EditText) findViewById(ids[i][j + 1]);
                String strText2 = etEntry.getText().toString();
                int option = Integer.valueOf(strText2);

                switch (option) {
                    case 1:
                        personalPriceArray[i][j] = newprice / peopleArray[j];
                        break;
                    case 2:
                        personalPriceArray[i][j] = (newprice / peopleArray[j]) - snackprice;
                        break;
                    case 3:
                        personalPriceArray[i][j] = (newprice / peopleArray[j]) - 4000;
                        break;
                    case 4:
                        personalPriceArray[i][j] = (newprice / peopleArray[j]) - (snackprice + 4000);
                        break;
                    default:
                        break;
                }
            }
        }
        for (int fin = 0; fin < MAX_MEMBER; fin++){
            personalPriceArray[fin][3] = personalPriceArray[fin][0] + personalPriceArray[fin][1] + personalPriceArray[fin][2];
        }

        for (int iLoop = 0; iLoop < row; iLoop++) {
            EditText etEntry = (EditText) findViewById(ids[iLoop][4]);
            String strPrice = String.valueOf(personalPriceArray[iLoop][3]);

            etEntry.setText(strPrice);
        }
    }
}

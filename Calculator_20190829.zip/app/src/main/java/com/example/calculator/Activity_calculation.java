package com.example.calculator;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

public class Activity_calculation extends AppCompatActivity {


    int[][] intArray = new int[10][4]; //[누구인지 구분][1차,2차,3차, 총 비용]
    int[][] typeArray = new int[5][3]; //[옵션][1차, 2차, 3차]
    int[] peopleArray = new int[3]; //[1차, 2차, 3차 인원]
    int[] priceArray = new int[3]; //[1차, 2차, 3차 비용]
    int[] optionArray = new int[3]; //[1차, 2차, 3차 안주개수]
    int[] nameArray = new int[10]; //이름이 입력되었는가 체크


    public static void calculation(int[] price, int[] optionArray,int[][] intArray, int[][] typeArray, int[] peopleArray) {

        int snackprice = 0;
        int newprice = 0;

        for(int j=0; j<3; j++) {

            switch (optionArray[j]) {
                case 1: snackprice = 5000;
                    break;
                default: snackprice = optionArray[j] * 4000;
                    break;
            }

            newprice = (price[j] + (snackprice * typeArray[1][j])+(4000 * typeArray[2][j])
            +(snackprice + 4000) * typeArray[3][j]);

            for (int i = 0; i < 10; i++) {

                int newinteger = Integer.valueOf(String("money" + j + "st_" + i));

                switch (newinteger) {
                    case 1:
                        intArray[i][j] = newprice / peopleArray[j];
                        break;
                    case 2:
                        intArray[i][j] = (newprice / peopleArray[j]) - snackprice;
                        break;
                    case 3:
                        intArray[i][j] = (newprice / peopleArray[j]) - 4000;
                        break;
                    case 4:
                        intArray[i][j] = (newprice / peopleArray[j]) - (snackprice + 4000);
                        break;
                    default:
                        break;
                }
            }
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculation);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        EditText money1 = (EditText) findViewById(R.id.editText_1st);
        String strMoney1 = money1.getText().toString();
        int money1st = Integer.valueOf(strMoney1);
        EditText money2 = (EditText) findViewById(R.id.editText_2nd);
        String strMoney2 = money2.getText().toString();
        int money2nd = Integer.valueOf(strMoney2);
        EditText money3 = (EditText) findViewById(R.id.editText_3rd);
        String strMoney3 = money3.getText().toString();
        int money3rd = Integer.valueOf(strMoney3);

        EditText edt1 = (EditText) findViewById(R.id.name_1);
        String strName1 = edt1.getText().toString();
        EditText edt2 = (EditText) findViewById(R.id.name_2);
        String strName2 = edt2.getText().toString();
        EditText edt3 = (EditText) findViewById(R.id.name_3);
        String strName3 = edt3.getText().toString();
        EditText edt4 = (EditText) findViewById(R.id.name_4);
        String strName4 = edt4.getText().toString();
        EditText edt5 = (EditText) findViewById(R.id.name_5);
        String strName5 = edt5.getText().toString();
        EditText edt6 = (EditText) findViewById(R.id.name_6);
        String strName6 = edt6.getText().toString();
        EditText edt7 = (EditText) findViewById(R.id.name_7);
        String strName7 = edt7.getText().toString();
        EditText edt8 = (EditText) findViewById(R.id.name_8);
        String strName8 = edt8.getText().toString();
        EditText edt9 = (EditText) findViewById(R.id.name_9);
        String strName9 = edt9.getText().toString();
        EditText edt10 = (EditText) findViewById(R.id.name_10);
        String strName10 = edt10.getText().toString();


        EditText money1_1 = (EditText) findViewById(R.id.first_1);
        String strMoney1_1 = money1_1.getText().toString();
        int money1st_1 = Integer.valueOf(strMoney1_1);
        EditText money1_2 = (EditText) findViewById(R.id.first_2);
        String strMoney1_2 = money1_2.getText().toString();
        int money1st_2 = Integer.valueOf(strMoney1_2);
        EditText money1_3 = (EditText) findViewById(R.id.first_3);
        String strMoney1_3 = money1_3.getText().toString();
        int money1st_3 = Integer.valueOf(strMoney1_3);
        EditText money1_4 = (EditText) findViewById(R.id.first_4);
        String strMoney1_4 = money1_4.getText().toString();
        int money1st_4 = Integer.valueOf(strMoney1_4);
        EditText money1_5 = (EditText) findViewById(R.id.first_5);
        String strMoney1_5 = money1_5.getText().toString();
        int money1st_5 = Integer.valueOf(strMoney1_5);
        EditText money1_6 = (EditText) findViewById(R.id.first_6);
        String strMoney1_6 = money1_6.getText().toString();
        int money1st_6 = Integer.valueOf(strMoney1_6);
        EditText money1_7 = (EditText) findViewById(R.id.first_7);
        String strMoney1_7 = money1_7.getText().toString();
        int money1st_7 = Integer.valueOf(strMoney1_7);
        EditText money1_8 = (EditText) findViewById(R.id.first_8);
        String strMoney1_8 = money1_8.getText().toString();
        int money1st_8 = Integer.valueOf(strMoney1_8);
        EditText money1_9 = (EditText) findViewById(R.id.first_9);
        String strMoney1_9 = money1_9.getText().toString();
        int money1st_9 = Integer.valueOf(strMoney1_9);
        EditText money1_10 = (EditText) findViewById(R.id.first_10);
        String strMoney1_10 = money1_10.getText().toString();
        int money1st_10 = Integer.valueOf(strMoney1_10);

        EditText money2_1 = (EditText) findViewById(R.id.second_1);
        String strMoney2_1 = money2_1.getText().toString();
        int money2nd_1 = Integer.valueOf(strMoney2_1);
        EditText money2_2 = (EditText) findViewById(R.id.second_2);
        String strMoney2_2 = money2_2.getText().toString();
        int money2nd_2 = Integer.valueOf(strMoney2_2);
        EditText money2_3 = (EditText) findViewById(R.id.second_3);
        String strMoney2_3 = money2_3.getText().toString();
        int money2nd_3 = Integer.valueOf(strMoney2_3);
        EditText money2_4 = (EditText) findViewById(R.id.second_4);
        String strMoney2_4 = money2_4.getText().toString();
        int money2nd_4 = Integer.valueOf(strMoney2_4);
        EditText money2_5 = (EditText) findViewById(R.id.second_5);
        String strMoney2_5 = money2_5.getText().toString();
        int money2nd_5 = Integer.valueOf(strMoney2_5);
        EditText money2_6 = (EditText) findViewById(R.id.second_6);
        String strMoney2_6 = money2_6.getText().toString();
        int money2nd_6 = Integer.valueOf(strMoney2_6);
        EditText money2_7 = (EditText) findViewById(R.id.second_7);
        String strMoney2_7 = money2_7.getText().toString();
        int money2nd_7 = Integer.valueOf(strMoney2_7);
        EditText money2_8 = (EditText) findViewById(R.id.second_8);
        String strMoney2_8 = money2_8.getText().toString();
        int money2nd_8 = Integer.valueOf(strMoney2_8);
        EditText money2_9 = (EditText) findViewById(R.id.second_9);
        String strMoney2_9 = money2_9.getText().toString();
        int money2nd_9 = Integer.valueOf(strMoney2_9);
        EditText money2_10 = (EditText) findViewById(R.id.second_10);
        String strMoney2_10 = money2_10.getText().toString();
        int money2nd_10 = Integer.valueOf(strMoney2_10);

        EditText money3_1 = (EditText) findViewById(R.id.third_1);
        String strMoney3_1 = money3_1.getText().toString();
        int money3rd_1 = Integer.valueOf(strMoney3_1);
        EditText money3_2 = (EditText) findViewById(R.id.third_2);
        String strMoney3_2 = money3_2.getText().toString();
        int money3rd_2 = Integer.valueOf(strMoney3_2);
        EditText money3_3 = (EditText) findViewById(R.id.third_3);
        String strMoney3_3 = money3_3.getText().toString();
        int money3rd_3 = Integer.valueOf(strMoney3_3);
        EditText money3_4 = (EditText) findViewById(R.id.third_4);
        String strMoney3_4 = money3_4.getText().toString();
        int money3rd_4 = Integer.valueOf(strMoney3_4);
        EditText money3_5 = (EditText) findViewById(R.id.third_5);
        String strMoney3_5 = money3_5.getText().toString();
        int money3rd_5 = Integer.valueOf(strMoney3_5);
        EditText money3_6 = (EditText) findViewById(R.id.third_6);
        String strMoney3_6 = money3_6.getText().toString();
        int money3rd_6 = Integer.valueOf(strMoney3_6);
        EditText money3_7 = (EditText) findViewById(R.id.third_7);
        String strMoney3_7 = money3_7.getText().toString();
        int money3rd_7 = Integer.valueOf(strMoney3_7);
        EditText money3_8 = (EditText) findViewById(R.id.third_8);
        String strMoney3_8 = money3_8.getText().toString();
        int money3rd_8 = Integer.valueOf(strMoney3_8);
        EditText money3_9 = (EditText) findViewById(R.id.third_9);
        String strMoney3_9 = money3_9.getText().toString();
        int money3rd_9 = Integer.valueOf(strMoney3_9);
        EditText money3_10 = (EditText) findViewById(R.id.third_10);
        String strMoney3_10 = money3_10.getText().toString();
        int money3rd_10 = Integer.valueOf(strMoney3_10);

        /*TextView sumpeop = (TextView) findViewById(R.id.sumpeople);
        sumpeop.setText(String.format("%d",);
        TextView sumpeop1 = (TextView) findViewById(R.id.sumpeople_1st);
        sumpeop1.setText(String.format("%d",50 - typeArray[4][0]));
        TextView sumpeop2 = (TextView) findViewById(R.id.sumpeople_2nd);
        sumpeop2.setText(String.format("%d",50 - typeArray[4][1]));
        TextView sumpeop3 = (TextView) findViewById(R.id.sumpeople_3rd);
        sumpeop3.setText(String.format("%d",50 - typeArray[4][2]));

        TextView summoney1 = (TextView) findViewById(R.id.sum_1);
        summoney1.setText(String.format("%d", intArray[0][3]));
        TextView summoney2 = (TextView) findViewById(R.id.sum_2);
        summoney2.setText(String.format("%d", intArray[1][3]));
        TextView summoney3 = (TextView) findViewById(R.id.sum_3);
        summoney3.setText(String.format("%d", intArray[2][3]));
        TextView summoney4 = (TextView) findViewById(R.id.sum_4);
        summoney4.setText(String.format("%d", intArray[3][3]));
        TextView summoney5 = (TextView) findViewById(R.id.sum_5);
        summoney5.setText(String.format("%d", intArray[4][3]));
        TextView summoney6 = (TextView) findViewById(R.id.sum_6);
        summoney6.setText(String.format("%d", intArray[5][3]));
        TextView summoney7 = (TextView) findViewById(R.id.sum_7);
        summoney7.setText(String.format("%d", intArray[6][3]));
        TextView summoney8 = (TextView) findViewById(R.id.sum_8);
        summoney8.setText(String.format("%d", intArray[7][3]));
        TextView summoney9 = (TextView) findViewById(R.id.sum_9);
        summoney9.setText(String.format("%d", intArray[8][3]));
        TextView summoney10 = (TextView) findViewById(R.id.sum_10);
        summoney10.setText(String.format("%d", intArray[9][3]));*/

        //int value = Integer.valueOf(strName3);

        /*FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });        */
    }

    public void onClick_calculate(View v) {

        for(int j=0; j<3; j++) {
            for (int i = 0; i < 10; i++) {
                int newinteger = Integer.valueOf(String("money" + j + "st_" + i));

                switch (newinteger) {
                    case 1:
                        typeArray[0][j]++;
                        break;
                    case 2:
                        typeArray[1][j]++;
                        break;
                    case 3:
                        typeArray[2][j]++;
                        break;
                    case 4:
                        typeArray[3][j]++;
                        break;
                    case 5:
                        typeArray[4][j]++;
                        break;
                    default:
                        Toast.makeText(this, "알 수 없는 오류입니다.", Toast.LENGTH_SHORT).show();
                        break;
                }
            }
            peopleArray[j] = 50-typeArray[4][j];
        }

        calculation(priceArray, optionArray, intArray, typeArray, peopleArray);

        TextView sumpeop = (TextView) findViewById(R.id.sumpeople);
        sumpeop.setText(String.format("%d",);
        TextView sumpeop1 = (TextView) findViewById(R.id.sumpeople_1st);
        sumpeop1.setText(String.format("%d",50 - typeArray[4][0]));
        TextView sumpeop2 = (TextView) findViewById(R.id.sumpeople_2nd);
        sumpeop2.setText(String.format("%d",50 - typeArray[4][1]));
        TextView sumpeop3 = (TextView) findViewById(R.id.sumpeople_3rd);
        sumpeop3.setText(String.format("%d",50 - typeArray[4][2]));

        TextView summoney1 = (TextView) findViewById(R.id.sum_1);
        summoney1.setText(String.format("%d", intArray[0][3]));
        TextView summoney2 = (TextView) findViewById(R.id.sum_2);
        summoney2.setText(String.format("%d", intArray[1][3]));
        TextView summoney3 = (TextView) findViewById(R.id.sum_3);
        summoney3.setText(String.format("%d", intArray[2][3]));
        TextView summoney4 = (TextView) findViewById(R.id.sum_4);
        summoney4.setText(String.format("%d", intArray[3][3]));
        TextView summoney5 = (TextView) findViewById(R.id.sum_5);
        summoney5.setText(String.format("%d", intArray[4][3]));
        TextView summoney6 = (TextView) findViewById(R.id.sum_6);
        summoney6.setText(String.format("%d", intArray[5][3]));
        TextView summoney7 = (TextView) findViewById(R.id.sum_7);
        summoney7.setText(String.format("%d", intArray[6][3]));
        TextView summoney8 = (TextView) findViewById(R.id.sum_8);
        summoney8.setText(String.format("%d", intArray[7][3]));
        TextView summoney9 = (TextView) findViewById(R.id.sum_9);
        summoney9.setText(String.format("%d", intArray[8][3]));
        TextView summoney10 = (TextView) findViewById(R.id.sum_10);
        summoney10.setText(String.format("%d", intArray[9][3]));
    }

    public void onClick_out(View v){
        String strValue = String.format(
        "이름  1차  2차  3차  총 비용\n%4s %4d %4d %4d %4d\n%4s %4d %4d %4d %4d\n%4s %4d %4d %4d %4d\n%4s %4d %4d %4d %4d\n%4s %4d %4d %4d %4d\n%4s %4d %4d %4d %4d\n%4s %4d %4d %4d %4d\n%4s %4d %4d %4d %4d\n%4s %4d %4d %4d %4d\n%4s %4d %4d %4d %4d\n",
                peopleArray[0], intArray[0][0], intArray[0][1], intArray[0][2], intArray[0][3],
                peopleArray[1], intArray[1][0], intArray[1][1], intArray[1][2], intArray[1][3],
                peopleArray[2], intArray[2][0], intArray[2][1], intArray[2][2], intArray[2][3],
                peopleArray[3], intArray[3][0], intArray[3][1], intArray[3][2], intArray[3][3],
                peopleArray[4], intArray[4][0], intArray[4][1], intArray[4][2], intArray[4][3],
                peopleArray[5], intArray[5][0], intArray[5][1], intArray[5][2], intArray[5][3],
                peopleArray[6], intArray[6][0], intArray[6][1], intArray[6][2], intArray[6][3],
                peopleArray[7], intArray[7][0], intArray[7][1], intArray[7][2], intArray[7][3],
                peopleArray[8], intArray[8][0], intArray[8][1], intArray[8][2], intArray[8][3],
                peopleArray[9], intArray[9][0], intArray[9][1], intArray[9][2], intArray[9][3]);
        ClipboardManager clipboard = (ClipboardManager)getSystemService(Context.CLIPBOARD_SERVICE);
        ClipData clip = ClipData.newPlainText("text", strValue);
        clipboard.setPrimaryClip(clip);
    }
}
